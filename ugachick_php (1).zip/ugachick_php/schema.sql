-- UgaChick MIS: MySQL schema (matches the ERD slide)
CREATE DATABASE IF NOT EXISTS ugachick_mis CHARACTER SET utf8mb4;
USE ugachick_mis;

CREATE TABLE users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name     VARCHAR(100) NOT NULL,
  role          ENUM('Administrator','Manager','Production Officer') NOT NULL
);

CREATE TABLE farms (
  farm_id  INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(100) NOT NULL,
  type     VARCHAR(50),
  location VARCHAR(100)
);

CREATE TABLE products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL UNIQUE,
  unit       VARCHAR(20) DEFAULT 'birds'
);

CREATE TABLE production_batch (
  batch_id        INT AUTO_INCREMENT PRIMARY KEY,
  product_id      INT NOT NULL,
  farm_id         INT NOT NULL,
  recorded_by     INT NOT NULL,
  quantity        INT NOT NULL CHECK (quantity > 0),
  production_date DATE NOT NULL,
  notes           VARCHAR(255),
  FOREIGN KEY (product_id)  REFERENCES products(product_id),
  FOREIGN KEY (farm_id)     REFERENCES farms(farm_id),
  FOREIGN KEY (recorded_by) REFERENCES users(user_id)
);

CREATE TABLE inventory (
  batch_id      INT PRIMARY KEY,
  qty_on_hand   INT NOT NULL,
  qty_reserved  INT NOT NULL DEFAULT 0,
  qty_available INT AS (qty_on_hand - qty_reserved) STORED,
  FOREIGN KEY (batch_id) REFERENCES production_batch(batch_id) ON DELETE CASCADE
);

CREATE TABLE customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  phone       VARCHAR(20)
);

CREATE TABLE orders (
  order_id     INT AUTO_INCREMENT PRIMARY KEY,
  customer_id  INT NOT NULL,
  product_id   INT NOT NULL,
  quantity     INT NOT NULL CHECK (quantity > 0),
  unit_price   DECIMAL(12,2) NOT NULL,
  total_amount DECIMAL(14,2) AS (quantity * unit_price) STORED,
  status       ENUM('Pending','Confirmed','Dispatched','Cancelled') NOT NULL DEFAULT 'Pending',
  order_date   DATE NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (product_id)  REFERENCES products(product_id)
);

CREATE TABLE qc_records (
  qc_id        INT AUTO_INCREMENT PRIMARY KEY,
  batch_id     INT NOT NULL,
  inspector_id INT NOT NULL,
  result       ENUM('Pass','Fail','Conditional') NOT NULL,
  check_date   DATE NOT NULL,
  notes        VARCHAR(255),
  FOREIGN KEY (batch_id)     REFERENCES production_batch(batch_id) ON DELETE CASCADE,
  FOREIGN KEY (inspector_id) REFERENCES users(user_id)
);

-- Starter data from the prototype
INSERT INTO products (name, unit) VALUES
 ('Broiler Chicken','birds'),('Day-old Chicks','chicks'),('Processed Chicken','birds'),('Layers','birds'),('Eggs','trays');
INSERT INTO farms (name, type, location) VALUES
 ('Namanve Farm','Farm','Namanve'),('Mukono Hatchery','Hatchery','Mukono'),
 ('Jinja Broiler Unit','Farm','Jinja'),('Processing Plant - Kampala','Plant','Kampala');

-- Demo users (passwords: admin123, mgr123, off123; stored as bcrypt hashes)
INSERT INTO users (username, password_hash, full_name, role) VALUES
 ('admin','$2y$10$Enq8kSDHFyyHwW3sgsmhPO0XM0SpFojl4AQqapf2qNmSSaiO43er2','JULIUS','Administrator'),
 ('manager','$2y$10$g.Fuo030WWKtSAUgZNEvQe4aSqcTUQ4ZPBBO643jUmJeXiJ3DR9wW','OLIVER','Manager'),
 ('officer','$2y$10$BT0sf9jjEuCbUf3XMfyUfeZO7QHerc1./iWGCUlz45V7kQpA6zE02','CHRISTINE','Production Officer');

-- Sample records copied from the prototype's data.js
INSERT INTO production_batch (product_id, farm_id, recorded_by, quantity, production_date, notes) VALUES
 (1,1,3,4500,'2026-11-05',''),
 (2,2,3,12000,'2026-11-07','Healthy batch'),
 (3,4,1,2800,'2026-11-08','');
INSERT INTO inventory (batch_id, qty_on_hand, qty_reserved) VALUES (1,4500,500),(2,12000,0),(3,2800,0);
INSERT INTO customers (name, phone) VALUES ('Fresh Mart Ltd','+256700111222'),('Kampala Distributors','+256772333444');
INSERT INTO orders (customer_id, product_id, quantity, unit_price, status, order_date) VALUES
 (1,1,500,18000,'Confirmed','2026-11-09'),
 (2,2,2000,2500,'Pending','2026-11-10');
INSERT INTO qc_records (batch_id, inspector_id, result, check_date, notes) VALUES
 (1,3,'Pass','2026-11-06','All parameters within range'),
 (2,3,'Pass','2026-11-07','');
