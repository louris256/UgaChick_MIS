<?php
// add_batch.php: record a production batch and create its inventory row
require 'db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = (int)($_POST['quantity'] ?? 0);
    if ($qty <= 0) {
        $message = 'Quantity must be greater than zero.';
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'INSERT INTO production_batch (product_id, farm_id, recorded_by, quantity, production_date, notes)
                 VALUES (?,?,?,?,?,?)'
            );
            // recorded_by = 1 for now; replace with the logged-in user's id
            $stmt->execute([$_POST['product_id'], $_POST['farm_id'], 1, $qty, $_POST['production_date'], $_POST['notes'] ?? '']);
            $id = (int)$pdo->lastInsertId();
            $pdo->prepare('INSERT INTO inventory (batch_id, qty_on_hand) VALUES (?,?)')->execute([$id, $qty]);
            $pdo->commit();
            $message = 'Production batch BAT-' . str_pad($id, 3, '0', STR_PAD_LEFT) . ' recorded successfully!';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = 'Could not save the batch.';
        }
    }
}
$products = $pdo->query('SELECT product_id, name FROM products ORDER BY name')->fetchAll();
$farms    = $pdo->query('SELECT farm_id, name FROM farms ORDER BY name')->fetchAll();
$batches  = $pdo->query(
    'SELECT b.batch_id, p.name AS product, f.name AS farm, b.quantity, b.production_date
     FROM production_batch b JOIN products p USING (product_id) JOIN farms f USING (farm_id)
     ORDER BY b.batch_id DESC LIMIT 10'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Record Production</title>
<style>body{font-family:system-ui,sans-serif;max-width:760px;margin:2rem auto;padding:0 1rem}
label{display:block;margin-top:.8rem}input,select{width:100%;padding:.5rem}
button{margin-top:1rem;padding:.6rem 1.2rem}table{width:100%;border-collapse:collapse;margin-top:1.5rem}
td,th{border-bottom:1px solid #ccc;padding:.4rem;text-align:left}</style></head>
<body>
<h2>Record Production Batch</h2>
<?php if ($message): ?><p><strong><?= htmlspecialchars($message) ?></strong></p><?php endif; ?>
<form method="post">
  <label>Product
    <select name="product_id" required>
      <?php foreach ($products as $p): ?><option value="<?= $p['product_id'] ?>"><?= htmlspecialchars($p['name']) ?></option><?php endforeach; ?>
    </select></label>
  <label>Farm / site
    <select name="farm_id" required>
      <?php foreach ($farms as $f): ?><option value="<?= $f['farm_id'] ?>"><?= htmlspecialchars($f['name']) ?></option><?php endforeach; ?>
    </select></label>
  <label>Quantity <input type="number" name="quantity" min="1" required></label>
  <label>Date <input type="date" name="production_date" value="<?= date('Y-m-d') ?>" required></label>
  <label>Notes <input type="text" name="notes" maxlength="255"></label>
  <button type="submit">Save batch</button>
</form>
<table><tr><th>Batch</th><th>Product</th><th>Farm</th><th>Qty</th><th>Date</th></tr>
<?php foreach ($batches as $b): ?>
<tr><td>BAT-<?= str_pad($b['batch_id'], 3, '0', STR_PAD_LEFT) ?></td><td><?= htmlspecialchars($b['product']) ?></td>
<td><?= htmlspecialchars($b['farm']) ?></td><td><?= number_format($b['quantity']) ?></td><td><?= $b['production_date'] ?></td></tr>
<?php endforeach; ?>
</table>
</body></html>
