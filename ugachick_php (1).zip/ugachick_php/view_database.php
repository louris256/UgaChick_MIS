<?php
// view_database.php: displays the ugachick_mis database (tables, columns, rows)
require 'db.php';
$dbName = $pdo->query('SELECT DATABASE()')->fetchColumn();
$tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>UgaChick MIS: Database</title>
<style>
body{font-family:system-ui,sans-serif;background:#0A1628;color:#E8EEF7;margin:0;padding:1.5rem}
h1{margin:0 0 .3rem}h2{margin:1.5rem 0 .4rem;color:#60A5FA}
.meta{color:#94A3B8;margin-bottom:1rem}
table{border-collapse:collapse;width:100%;background:#12233D;font-size:.9rem}
th{background:#1A2F4A;color:#94A3B8;text-align:left;padding:.5rem .7rem;font-size:.75rem;text-transform:uppercase}
td{padding:.5rem .7rem;border-bottom:1px solid #1E3A5F}
.wrap{overflow-x:auto}.key{color:#F59E0B}
</style></head><body>
<h1>UgaChick MIS database</h1>
<div class="meta">Database: <strong><?= e($dbName) ?></strong> · MySQL via PHP PDO · <?= count($tables) ?> tables</div>
<?php foreach ($tables as $t):
    $cols = $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll();
    $rows = $pdo->query("SELECT * FROM `$t`")->fetchAll();
    $count = count($rows); ?>
  <h2><?= e($t) ?> <small style="color:#94A3B8">(<?= $count ?> rows)</small></h2>
  <div class="wrap"><table>
    <tr><?php foreach ($cols as $c): ?>
      <th><?= e($c['Field']) ?><?= $c['Key'] === 'PRI' ? ' <span class="key">PK</span>' : ($c['Key'] === 'MUL' ? ' <span class="key">FK</span>' : '') ?><br><span style="text-transform:none"><?= e($c['Type']) ?></span></th>
    <?php endforeach; ?></tr>
    <?php foreach ($rows as $r): ?><tr>
      <?php foreach ($r as $k => $v): ?><td><?= $k === 'password_hash' ? '(hashed)' : e($v) ?></td><?php endforeach; ?>
    </tr><?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="<?= count($cols) ?>">No records</td></tr><?php endif; ?>
  </table></div>
<?php endforeach; ?>
</body></html>
