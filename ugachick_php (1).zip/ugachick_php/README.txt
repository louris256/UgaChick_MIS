UgaChick MIS: MySQL + PHP backend files

1. Start Apache and MySQL (XAMPP or WAMP).
2. In phpMyAdmin, import schema.sql. It creates the ugachick_mis database,
   all 8 tables, 3 demo users and the sample data from the prototype.
3. Copy this folder to htdocs/ugachick/ and edit db.php if your MySQL
   user or password is not root with an empty password.
4. Open http://localhost/ugachick/view_database.php to display the database.
5. Open http://localhost/ugachick/add_batch.php to record a production batch.

db.php             PDO connection used by every page
schema.sql         tables, relationships, demo users, sample data
view_database.php  shows every table with its columns and rows
add_batch.php      saves a batch and its inventory row (transaction)
Demo logins: admin/admin123, manager/mgr123, officer/off123
